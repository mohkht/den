import React from 'react';
import { Award, Users, Heart, Shield } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            About Yacoub Dental
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Leading dental clinic in Amman, Jordan, providing comprehensive oral healthcare with state-of-the-art technology and personalized care.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <img
              src="https://images.pexels.com/photos/4687360/pexels-photo-4687360.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Modern dental clinic interior at Yacoub Dental Amman"
              className="rounded-lg shadow-lg w-full h-auto"
            />
          </div>
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-900">
              Exceptional Dental Care in the Heart of Amman
            </h3>
            <p className="text-gray-600 leading-relaxed">
              At Yacoub Dental, we combine advanced dental technology with compassionate care to deliver the best possible outcomes for our patients. Located in Amman, Jordan, we serve families throughout the region with comprehensive dental services.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Our commitment to excellence and patient comfort has made us one of the most trusted dental practices in Jordan. We believe that everyone deserves a healthy, beautiful smile.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">15+</div>
                <div className="text-sm text-gray-600">Years of Experience</div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">500+</div>
                <div className="text-sm text-gray-600">Satisfied Patients</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="text-center p-6 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
            <Award className="mx-auto mb-4 text-blue-600" size={48} />
            <h4 className="text-lg font-semibold text-gray-900 mb-2">Expert Care</h4>
            <p className="text-gray-600 text-sm">
              Highly qualified dentists with international training and certifications.
            </p>
          </div>
          <div className="text-center p-6 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
            <Users className="mx-auto mb-4 text-blue-600" size={48} />
            <h4 className="text-lg font-semibold text-gray-900 mb-2">Family Friendly</h4>
            <p className="text-gray-600 text-sm">
              Comprehensive dental care for patients of all ages in a comfortable environment.
            </p>
          </div>
          <div className="text-center p-6 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
            <Heart className="mx-auto mb-4 text-blue-600" size={48} />
            <h4 className="text-lg font-semibold text-gray-900 mb-2">Gentle Touch</h4>
            <p className="text-gray-600 text-sm">
              Pain-free procedures with advanced techniques and sedation options.
            </p>
          </div>
          <div className="text-center p-6 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
            <Shield className="mx-auto mb-4 text-blue-600" size={48} />
            <h4 className="text-lg font-semibold text-gray-900 mb-2">Safe & Clean</h4>
            <p className="text-gray-600 text-sm">
              Strict sterilization protocols and infection control measures for your safety.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;